"""
긁기 강도 오분류 진단 연구 도구 (Streamlit, Rule-based)

방식: 신호 특징의 '약 기준'·'강 기준' 두 앵커 → 새 긁기의 위치(0~1) → 경계로 약/보통/강.
머신러닝 없음(임계값 기반). 검증은 LOOCV/LOSO로 학습·평가 샘플이 겹치지 않게 한다.

핵심 목적: 숫자 정확도가 아니라 "왜 틀렸나"를 눈으로 진단.
 → 오분류 긁기의 스펙트로그램을, 같은 실제 라벨의 정분류 긁기와 나란히(동일 색 스케일) 비교.

실행: pip install -r requirements.txt && streamlit run app.py
"""
import json
import numpy as np, pandas as pd, streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from scipy import signal as sps
from scipy.stats import spearmanr
from sklearn.metrics import f1_score, cohen_kappa_score

np.random.seed(0)  # 재현성(현재 파이프라인엔 난수 없음, 원칙상 고정)

FS = 100
DATA_PATH = "sample_data.ndjson"
KR = {'weak': '약', 'normal': '보통', 'strong': '강'}
COLOR = {'weak': '#10B981', 'normal': '#F59E0B', 'strong': '#EF4444'}
ACCENT = '#6366F1'
GRAY = '#94A3B8'
LABELS = ['약', '보통', '강']
LAB_MAP = {'약': 0, '보통': 1, '강': 2}
INT3 = {'weak': 0, 'normal': 1, 'strong': 2}
FEATS_ALL = {'std': '진폭(std)', 'jerk': '저크', 'peak_freq': '주파수 피크(Hz)',
             'energy': '에너지', 'gyro_std': '자이로(std)'}
META = {'subject_id': '사람', 'body_region': '부위', 'method': '방식', 'posture': '자세'}
VAL_KR = {'head_neck': '머리·목', 'arm': '팔', 'torso': '몸통', 'leg': '다리',
          'finger': '손가락', 'supine': '누움', 'side': '옆으로', 'prone': '엎드림', 'sitting': '앉음'}


def vk(v):
    return VAL_KR.get(v, v)


def amag(d):
    a = d['accel']
    return np.sqrt(np.array(a['x'])**2 + np.array(a['y'])**2 + np.array(a['z'])**2)


def gmag(d):
    g = d.get('gyro')
    if not g:
        return None
    return np.sqrt(np.array(g['x'])**2 + np.array(g['y'])**2 + np.array(g['z'])**2)


def features(d):
    m = amag(d); m0 = m - m.mean()
    fr = np.fft.rfftfreq(len(m0), 1 / FS); ps = np.abs(np.fft.rfft(m0))**2
    g = gmag(d)
    return {'std': float(m.std()),
            'jerk': float(np.abs(np.diff(m)).mean()),
            'peak_freq': float(fr[ps.argmax()]),
            'energy': float((m0**2).sum()),
            'gyro_std': float(g.std()) if g is not None else np.nan}


@st.cache_data
def load_sample(path):
    return [json.loads(l) for l in open(path, encoding='utf-8') if l.strip()]


def build_frame(data):
    recs = []
    for i, d in enumerate(data):
        if d.get('label') != 'SCRATCH' or d.get('intensity') not in INT3:
            continue
        r = features(d); r['idx'] = i; r['intensity'] = d['intensity']; r['강도'] = KR[d['intensity']]
        for f in META:
            r[f] = d.get(f, '?')
        recs.append(r)
    return pd.DataFrame(recs)


def cv_scores(frame, feats, mode):
    """LOOCV/LOSO 위치점수. 특징 1개면 (값-약기준)/(강기준-약기준).
    2개 이상이면 표준화 후 '약 중심 → 강 중심' 축에 투영(0~1) — 경계는 그 축에 수직인 초평면.
    학습 통계(표준화·앵커)는 held-out(자신/자기 피험자)을 제외하고 계산해 정직하게."""
    if isinstance(feats, str):
        feats = [feats]
    X = frame[feats].to_numpy(float)
    lab = frame['intensity'].to_numpy(); subj = frame['subject_id'].to_numpy()
    n = len(frame); out = np.full(n, np.nan)
    for i in range(n):
        train = (subj != subj[i]) if mode == 'LOSO' else (np.arange(n) != i)
        Xtr = X[train]
        mu = Xtr.mean(0); sd = Xtr.std(0); sd[sd == 0] = 1.0
        Z = (X - mu) / sd
        w = Z[train & (lab == 'weak')]; s = Z[train & (lab == 'strong')]
        cw = w.mean(0) if len(w) else Z[train].mean(0)
        cs = s.mean(0) if len(s) else Z[train].mean(0)
        a = cs - cw; aa = float((a * a).sum()) + 1e-9
        out[i] = np.clip(float(((Z[i] - cw) * a).sum()) / aa, 0, 1)
    return out


def predict(score, lo, hi):
    return np.where(score < lo, '약', np.where(score > hi, '강', '보통'))


def qwk_acc(y, p):
    q = cohen_kappa_score(y, p, weights='quadratic') if len(set(p)) > 1 else 0.0
    return q, float((np.array(p) == np.array(y)).mean())


def spectro(m):
    nper = 128 if len(m) >= 128 else 64
    f, t, Sxx = sps.spectrogram(m - m.mean(), fs=FS, nperseg=nper, noverlap=nper // 2)
    return f, t, 10 * np.log10(Sxx + 1e-10)


def spec_fig(m, height=240, zrange=None):
    f, t, Z = spectro(m)
    kw = dict(z=Z, x=t, y=f, colorscale='Viridis', showscale=False)
    if zrange:
        kw['zmin'], kw['zmax'] = zrange
    fig = go.Figure(go.Heatmap(**kw))
    fig.update_layout(height=height, margin=dict(l=6, r=6, t=6, b=6), xaxis_title="시간(s)", yaxis_title="주파수(Hz)")
    return fig


def wave_fig(m, color=ACCENT, height=150):
    fig = go.Figure(go.Scatter(y=m, mode='lines', line=dict(color=color, width=1.2)))
    fig.update_layout(height=height, margin=dict(l=6, r=6, t=6, b=6), showlegend=False, yaxis_title="가속도 크기")
    return fig


def confusion_fig(res, height=330):
    cm = pd.crosstab(res['강도'], res['예측']).reindex(index=LABELS, columns=LABELS, fill_value=0)
    fig = go.Figure(go.Heatmap(z=cm.values, x=LABELS, y=LABELS, colorscale='Blues',
                               text=cm.values, texttemplate="%{text}", showscale=False))
    fig.update_layout(height=height, margin=dict(l=6, r=6, t=6, b=6), xaxis_title="예측", yaxis_title="실제")
    return fig


ENG = {'약': 'weak', '보통': 'normal', '강': 'strong'}


def overview_fig(res, lo, hi):
    """오분류 한눈에: 위치점수 스트립. x=위치, y=실제강도 레인, 배경=예측구간, X=오분류(색=예측)."""
    ymap = {'약': 0, '보통': 1, '강': 2}
    fig = go.Figure()
    fig.add_vrect(x0=0, x1=lo, fillcolor=COLOR['weak'], opacity=.08, line_width=0)
    fig.add_vrect(x0=lo, x1=hi, fillcolor=COLOR['normal'], opacity=.08, line_width=0)
    fig.add_vrect(x0=hi, x1=1, fillcolor=COLOR['strong'], opacity=.08, line_width=0)
    fig.add_vline(x=lo, line_dash='dot', line_color='gray'); fig.add_vline(x=hi, line_dash='dot', line_color='gray')
    for lab in LABELS:
        d = res[res['강도'] == lab].sort_values('위치').reset_index(drop=True)
        if d.empty:
            continue
        m = len(d)
        yj = ymap[lab] + (np.linspace(-0.32, 0.32, m) if m > 1 else np.array([0.0]))
        for correct in (True, False):
            dd = d[d['정답'] == correct]
            if dd.empty:
                continue
            pos = dd.index.to_numpy()
            hov = [f"idx {int(r['idx'])} · 실제 {r['강도']} → 예측 {r['예측']} · 위치 {r['위치']:.2f}"
                   for _, r in dd.iterrows()]
            fig.add_trace(go.Scatter(
                x=dd['위치'], y=yj[pos], mode='markers', showlegend=False, text=hov, hoverinfo='text',
                marker=dict(color=[COLOR[ENG[p]] for p in dd['예측']], size=(9 if correct else 15),
                            symbol=('circle' if correct else 'x'), opacity=(.5 if correct else 1),
                            line=dict(width=(0 if correct else 2), color='#111'))))
    fig.update_layout(height=330, margin=dict(l=6, r=6, t=10, b=6),
                      xaxis=dict(title='위치 점수 (0=약 기준 · 1=강 기준)', range=[-0.02, 1.02]),
                      yaxis=dict(tickmode='array', tickvals=[0, 1, 2], ticktext=LABELS,
                                 title='실제 강도', range=[-0.6, 2.6]))
    return fig


def boundary2d_fig(frame, sel, lo, hi, names):
    """특징 2개일 때 결정 경계를 2D로 시각화: 표준화 공간에서 약↔강 축 + 경계선 두 개(띠)."""
    X = frame[sel].to_numpy(float)
    mu = X.mean(0); sd = X.std(0); sd[sd == 0] = 1.0
    Z = (X - mu) / sd; lab = frame['intensity'].to_numpy()
    cw = Z[lab == 'weak'].mean(0); cs = Z[lab == 'strong'].mean(0)
    a = cs - cw; perp = np.array([-a[1], a[0]]); perp = perp / (np.hypot(*perp) + 1e-9)
    fig = go.Figure()
    for g in ['weak', 'normal', 'strong']:
        m = lab == g
        fig.add_trace(go.Scatter(x=Z[m, 0], y=Z[m, 1], mode='markers', name=KR[g],
                                 marker=dict(color=COLOR[g], size=9, opacity=.8, line=dict(width=.5, color='white'))))
    fig.add_trace(go.Scatter(x=[cw[0], cs[0]], y=[cw[1], cs[1]], mode='markers+lines', name='약↔강 축',
                             marker=dict(color='#111', size=13, symbol='x'), line=dict(color='#888', dash='dash')))
    for p, nm in [(lo, '약↔보통 경계'), (hi, '보통↔강 경계')]:
        c0 = cw + p * a; p1 = c0 - 3 * perp; p2 = c0 + 3 * perp
        fig.add_trace(go.Scatter(x=[p1[0], p2[0]], y=[p1[1], p2[1]], mode='lines', name=nm,
                                 line=dict(color='#64748B', dash='dot', width=2)))
    fig.update_layout(height=460, margin=dict(l=6, r=6, t=6, b=6),
                      xaxis_title=f"{names[0]} (표준화)", yaxis_title=f"{names[1]} (표준화)",
                      legend=dict(orientation='h', y=1.08))
    return fig


st.set_page_config(page_title="긁기 강도 오분류 진단", page_icon=":material/troubleshoot:", layout="wide")

# ── 사이드바: 데이터 · 특징 · 검증 · 경계 · 필터 ─────────────────
with st.sidebar:
    st.markdown("#### :material/database: 데이터")
    up = st.file_uploader("NDJSON 업로드 (선택)", type=['ndjson', 'jsonl', 'json', 'txt'])
    if up is not None:
        data = [json.loads(l) for l in up.getvalue().decode('utf-8').splitlines() if l.strip()]
        st.caption(f"업로드: **{up.name}** · {len(data)}줄")
    else:
        data = load_sample(DATA_PATH)
        st.caption("기본: sample_data.ndjson")
    full = build_frame(data)

    feats = [k for k in FEATS_ALL if full[k].notna().any() and full[k].std(skipna=True) > 0]
    FEATS = {k: FEATS_ALL[k] for k in feats}
    # 기본 추천 = 강도와 상관(|Spearman rho|)이 가장 큰 특징
    rho0 = {k: abs(spearmanr(full[k], full['intensity'].map(INT3))[0] or 0) for k in feats}
    best = max(feats, key=lambda k: rho0[k])

    st.markdown("#### :material/tune: 분류 · 검증")
    sel = st.multiselect("분류 특징 (여러 개 선택 가능)", feats, default=[best],
                         format_func=lambda k: FEATS[k] + (' ⭐' if k == best else ''))
    sel = sel or [best]
    multi = len(sel) > 1
    feat = sel[0]  # 단일 표시용 대표
    if multi:
        st.caption(f"{len(sel)}개 조합 — 표준화 후 약↔강 중심축에 투영해 위치를 계산합니다 (경계가 다차원).")
    nsubj = full['subject_id'].nunique()
    mode = st.radio("검증 방식", (['LOOCV', 'LOSO'] if nsubj > 1 else ['LOOCV']), horizontal=True,
                    help="LOOCV=샘플 1개씩 제외 / LOSO=피험자 1명씩 제외(2명 이상 필요). 학습·평가 미겹침.")
    lo = st.slider("약 ↔ 보통 경계", 0.0, 0.5, 0.4, 0.05)
    hi = st.slider("보통 ↔ 강 경계", 0.5, 1.0, 0.6, 0.05)

    st.markdown("#### :material/filter_list: 필터")
    varying = {f: sorted(full[f].unique()) for f in META if full[f].nunique() > 1}
    frame = full
    if varying:
        for f, vals in varying.items():
            chosen = st.multiselect(META[f], vals, default=vals, format_func=vk, key=f"flt_{f}")
            frame = frame[frame[f].isin(chosen or vals)]
        st.caption(f"선택 **{len(frame)}** / {len(full)}개")
    else:
        st.caption("값이 여러 개인 축이 아직 없습니다. 데이터가 쌓이면 필터가 늘어납니다.")

if frame.empty or frame['강도'].nunique() < 2:
    st.warning("분석에 필요한 데이터가 부족합니다(최소 2개 강도). 필터를 넓혀 주세요."); st.stop()
frame = frame.reset_index(drop=True)

# ── CV 판정 ─────────────────────────────────────────────────────
res = frame.copy()
res['위치'] = cv_scores(frame, sel, mode).round(3)
res['예측'] = predict(res['위치'].values, lo, hi)
res['정답'] = res['예측'] == res['강도']
yt = res['강도'].map(LAB_MAP).values
yp = res['예측'].map(LAB_MAP).values
qwk, acc = qwk_acc(yt, yp)
severe = int(((yt == 0) & (yp == 2)).sum() + ((yt == 2) & (yp == 0)).sum())

st.title("긁기 강도 오분류 진단")
if multi:
    st.caption(f"분류 특징 **{' + '.join(FEATS[k] for k in sel)}** ({len(sel)}개 조합) · 검증 **{mode}** · "
               "표준화 후 약↔강 축 투영 (지표는 교차검증 결과)")
else:
    gw = full[full.intensity == 'weak'][feat].mean(); gs = full[full.intensity == 'strong'][feat].mean()
    st.caption(f"분류 특징 **{FEATS[feat]}** · 검증 **{mode}** · 약 기준 {gw:.2f} · 강 기준 {gs:.2f} "
               "(지표는 학습·평가가 겹치지 않는 교차검증 결과)")

with st.container(horizontal=True):
    st.metric(f"정확도 ({mode})", f"{acc:.0%}", border=True)
    st.metric("QWK (순서형)", f"{qwk:.2f}", border=True, help="약<보통<강 순서 반영. 1에 가까울수록 좋음.")
    st.metric("심각 오류", severe, border=True, help="약↔강 정반대 혼동. 0이 목표.")
    st.metric("오분류 / 전체", f"{int((~res['정답']).sum())} / {len(res)}", border=True)

t_diag, t_pat, t_feat, t_opt = st.tabs([
    ":material/troubleshoot: 오분류 진단", ":material/analytics: 패턴 요약",
    ":material/science: 특징 비교", ":material/target: 경계 최적화"])

# ── 탭 1: 오분류 진단 (이 도구의 핵심) ───────────────────────────
with t_diag:
    wrong = res[~res['정답']].reset_index(drop=True)
    box = st.container(border=True)
    box.markdown("**오분류 한눈에 보기** · 배경색=예측 구간 · ○ 정분류 · ✕ 오분류(색=예측된 강도)")
    box.plotly_chart(overview_fig(res, lo, hi), width="stretch")
    box.caption("정분류는 약(왼쪽)→강(오른쪽) 대각선을 이룹니다. **대각선에서 벗어난 ✕가 오분류** — "
                "경계 근처면 아슬아슬한 오류, 약 레인의 ✕가 오른쪽 끝(강 구간)이면 심각 오류입니다. 점에 마우스를 올리면 상세가 보입니다.")

    st.markdown(f"**오분류 {len(wrong)}건** — 표에서 하나를 고르면, 같은 실제 라벨의 정분류 샘플과 나란히 비교합니다.")
    if wrong.empty:
        st.success("오분류 없음 — 비교할 샘플이 없습니다.", icon=":material/check_circle:")
    else:
        metacols = [f for f in META if res[f].nunique() > 1]
        vcols = ['강도', '예측', '위치'] + ([feat] if not multi else []) + metacols
        view = wrong[vcols].copy()
        if not multi:
            view[feat] = view[feat].round(2)
        for f in metacols:
            view[f] = view[f].map(vk)
        rename = {f: META[f] for f in metacols}
        if not multi:
            rename[feat] = FEATS[feat]
        ev = st.dataframe(view.rename(columns=rename), width="stretch", hide_index=True,
                          on_select="rerun", selection_mode="single-row", key="wsel")
        picks = ev.selection.rows
        if not picks:
            st.info("위 표에서 오분류 샘플을 클릭하세요.", icon=":material/ads_click:")
        else:
            wr = wrong.iloc[picks[0]]; L = wr['강도']
            same_ok = res[(res['강도'] == L) & (res['정답'])].sort_values('위치').reset_index(drop=True)
            st.markdown(f"#### 실제 :green[{L}] 인데 :red[{wr['예측']}] 로 오분류 &nbsp;—&nbsp; "
                        f"무엇이 달라서 틀렸나?")
            if same_ok.empty:
                st.warning(f"같은 실제 라벨('{L}')의 정분류 샘플이 없어 비교 대상이 없습니다.")
                ci = None
            else:
                ci = st.selectbox("비교할 정분류 샘플(같은 실제 라벨)", range(len(same_ok)),
                                  index=len(same_ok) // 2,
                                  format_func=lambda j: f"idx {int(same_ok.loc[j,'idx'])} · 위치 {same_ok.loc[j,'위치']:.2f}")

            mw = amag(data[int(wr['idx'])])
            zr = None
            if ci is not None:
                cr = same_ok.loc[ci]; mc = amag(data[int(cr['idx'])])
                _, _, Zw = spectro(mw); _, _, Zc = spectro(mc)
                zr = (min(Zw.min(), Zc.min()), max(Zw.max(), Zc.max()))  # 공정 비교용 동일 색 스케일

            cL, cR = st.columns(2)
            with cL:
                b = st.container(border=True)
                b.markdown(f"**:red[❌ 오분류]** · 실제 {L} → 예측 {wr['예측']} · 위치 {wr['위치']:.2f}")
                b.plotly_chart(spec_fig(mw, zrange=zr), width="stretch", key="dw_spec")
                b.plotly_chart(wave_fig(mw, color=COLOR.get({'약': 'weak', '보통': 'normal', '강': 'strong'}[L])), width="stretch", key="dw_wave")
            with cR:
                if ci is None:
                    st.container(border=True).info("비교 대상 없음")
                else:
                    b = st.container(border=True)
                    b.markdown(f"**:green[✅ 정분류 비교]** · 실제 {L} → 예측 {L} · 위치 {cr['위치']:.2f}")
                    b.plotly_chart(spec_fig(mc, zrange=zr), width="stretch", key="dc_spec")
                    b.plotly_chart(wave_fig(mc, color=COLOR[{'약': 'weak', '보통': 'normal', '강': 'strong'}[L]]), width="stretch", key="dc_wave")

            if ci is not None:
                st.markdown("**특징값 비교** — 어떤 특징이 얼마나 달라 오분류로 이어졌나")
                cmp = pd.DataFrame({'특징': [FEATS[k] for k in FEATS],
                                    '❌ 오분류': [round(wr[k], 3) for k in FEATS],
                                    '✅ 정분류': [round(cr[k], 3) for k in FEATS]})
                cmp['차이(%)'] = [f"{(wr[k]-cr[k])/(abs(cr[k])+1e-9)*100:+.0f}%" for k in FEATS]
                st.dataframe(cmp, width="stretch", hide_index=True)
                st.caption("색 스케일을 두 스펙트로그램에 동일 적용했습니다 — 밝기·주파수 분포 차이를 직접 비교하세요.")

# ── 탭 2: 패턴 요약 ─────────────────────────────────────────────
with t_pat:
    c1, c2 = st.columns([2, 3])
    with c1:
        box = st.container(border=True); box.markdown(f"**혼동행렬** · 정확도 {acc:.0%}")
        box.plotly_chart(confusion_fig(res), width="stretch")
    with c2:
        box = st.container(border=True); box.markdown("**조건별 오분류율** · 어디서 많이 틀리나")
        if varying:
            dfp = res.copy(); dfp['오분류'] = (~dfp['정답']).astype(int)
            fig = go.Figure()
            for f in varying:
                g = dfp.groupby(f)['오분류'].mean()
                fig.add_trace(go.Bar(x=[f"{META[f]}·{vk(i)}" for i in g.index], y=g.values * 100,
                                     name=META[f]))
            fig.update_layout(height=330, margin=dict(l=6, r=6, t=6, b=6), yaxis_title="오분류율(%)",
                              yaxis_range=[0, 100], legend=dict(orientation='h', y=1.12), showlegend=len(varying) > 1)
            box.plotly_chart(fig, width="stretch")
        else:
            box.caption("조건(부위·사람 등) 변이가 아직 없습니다. 데이터가 쌓이면 채워집니다.")

    primary = 'body_region' if res['body_region'].nunique() > 1 else next(iter(varying), None)
    if primary:
        box = st.container(border=True)
        box.markdown(f"**{META[primary]} × 강도 정확도** · 빨강 칸이 집중 오분류")
        piv = res.pivot_table(index=primary, columns='강도', values='정답', aggfunc='mean').reindex(columns=LABELS)
        cnt = res.pivot_table(index=primary, columns='강도', values='정답', aggfunc='count').reindex(columns=LABELS)
        ylab = [vk(v) for v in piv.index]
        txt = [[("-" if pd.isna(piv.values[r][c]) else f"{piv.values[r][c]*100:.0f}%<br>({int(cnt.values[r][c] or 0)})")
                for c in range(piv.shape[1])] for r in range(piv.shape[0])]
        fig = go.Figure(go.Heatmap(z=piv.values * 100, x=LABELS, y=ylab, zmin=0, zmax=100,
                                   colorscale='RdYlGn', text=txt, texttemplate="%{text}", colorbar=dict(title="정확도%")))
        fig.update_layout(height=110 + 46 * len(ylab), margin=dict(l=6, r=6, t=6, b=6),
                          xaxis_title="실제 강도", yaxis_title=META[primary])
        box.plotly_chart(fig, width="stretch")

# ── 탭 3: 특징 비교 (연구용) ─────────────────────────────────────
with t_feat:
    st.markdown("**특징별 강도 분리력** — Spearman rho(강도 순서와의 상관)와 단일특징 QWK")
    rows = []
    yint = frame['강도'].map(LAB_MAP).values
    for k in FEATS:
        rho = spearmanr(frame[k], frame['intensity'].map(INT3))[0]
        p = predict(cv_scores(frame, k, mode), lo, hi)
        q, a = qwk_acc(yint, pd.Series(p).map(LAB_MAP).values)
        rows.append({'k': k, '특징': FEATS[k], 'rho': rho if rho == rho else 0.0, 'QWK': q, '정확도': a})
    fdf = pd.DataFrame(rows).sort_values('rho')
    c1, c2 = st.columns([3, 2])
    with c1:
        box = st.container(border=True); box.markdown("**|Spearman rho| 순위** · 현재 선택=보라")
        fig = go.Figure(go.Bar(y=fdf['특징'], x=fdf['rho'].abs(), orientation='h',
                               marker_color=[ACCENT if k in sel else GRAY for k in fdf['k']],
                               text=[f"{r:.2f}" for r in fdf['rho']], textposition='auto'))
        fig.update_layout(height=300, margin=dict(l=6, r=6, t=6, b=6), xaxis=dict(range=[0, 1], title="|rho|"))
        box.plotly_chart(fig, width="stretch")
    with c2:
        box = st.container(border=True); box.markdown("**수치**")
        show = fdf.sort_values('rho', key=lambda s: s.abs(), ascending=False)[['특징', 'rho', 'QWK', '정확도']].copy()
        show['rho'] = show['rho'].round(2); show['QWK'] = show['QWK'].round(2)
        show['정확도'] = (show['정확도'] * 100).round(0).astype(int).astype(str) + '%'
        box.dataframe(show, width="stretch", hide_index=True)

    best_single_q = fdf['QWK'].max()
    if multi:
        verdict = "조합이 더 낫습니다 ✅" if qwk > best_single_q + 1e-9 else "조합이 단일보다 낫지 않습니다 — 단순한 단일 특징을 권장 ⚠️"
        st.info(f"선택한 {len(sel)}개 조합 QWK **{qwk:.2f}** vs 최고 단일 특징 QWK **{best_single_q:.2f}** → {verdict}",
                icon=":material/balance:")
    else:
        st.caption("여러 특징을 함께 고르면(사이드바) 여기서 '조합 vs 단일' 성능을 비교하고, 정확히 2개면 아래에 2D 결정 경계가 그려집니다.")

    box = st.container(border=True)
    box.markdown("**특징별 분포(박스)** · 약/보통/강이 잘 벌어질수록 좋은 특징")
    fk = list(FEATS); ncol = min(3, len(fk)); nrow = (len(fk) + ncol - 1) // ncol
    grid = make_subplots(rows=nrow, cols=ncol, subplot_titles=[FEATS[k] for k in fk],
                         vertical_spacing=0.16, horizontal_spacing=0.08)
    for i, k in enumerate(fk):
        r, c = i // ncol + 1, i % ncol + 1
        for g in ['weak', 'normal', 'strong']:
            sub = res[res.intensity == g]
            grid.add_trace(go.Box(y=sub[k], name=KR[g], legendgroup=KR[g], showlegend=(i == 0),
                                  marker_color=COLOR[g], boxpoints='all', jitter=0.4, line=dict(width=1)), row=r, col=c)
    for ann, k in zip(grid.layout.annotations, fk):
        ann.font.size = 12
        if k in sel:
            ann.text += " ⭐"; ann.font.color = ACCENT
    grid.update_layout(height=230 * nrow, margin=dict(l=6, r=6, t=30, b=6), boxmode='group',
                       legend=dict(orientation='h', y=1.06, x=0.5, xanchor='center'))
    box.plotly_chart(grid, width="stretch")

    if len(sel) == 2:
        box = st.container(border=True)
        box.markdown(f"**2D 결정 경계** · {FEATS[sel[0]]} × {FEATS[sel[1]]} (표준화 공간)")
        box.plotly_chart(boundary2d_fig(frame, sel, lo, hi, [FEATS[sel[0]], FEATS[sel[1]]]), width="stretch")
        box.caption("×표=약·강 중심(앵커), 점선=두 중심을 잇는 축, 회색 점선 2개=경계. "
                    "특징 1개일 땐 점이던 경계가, 2개가 되면 이렇게 **직선(띠)** 이 됩니다.")
    elif multi:
        st.caption(f"현재 {len(sel)}개 특징 → 경계는 {len(sel)}차원 공간의 초평면입니다(그림은 정확히 2개일 때 제공).")

# ── 탭 4: 경계 최적화 ───────────────────────────────────────────
with t_opt:
    st.markdown("**경계 자동 최적화** — 강도는 순서형(약<보통<강)이라 기준마다 최적 경계가 다릅니다. QWK 권장.")
    st.caption(f"현재 경계 [{lo:.2f}, {hi:.2f}] · 정확도 {acc:.0%} · QWK {qwk:.2f} · 심각오류 {severe}")
    if st.button("최적 경계 찾기", type="primary"):
        sc_all = res['위치'].values

        def cls(L, H):
            return np.where(sc_all < L, 0, np.where(sc_all > H, 2, 1))

        def m_all(p):
            return {'정확도': float((p == yt).mean()),
                    'macro-F1': f1_score(yt, p, average='macro', labels=[0, 1, 2], zero_division=0),
                    'QWK': cohen_kappa_score(yt, p, weights='quadratic') if len(set(p)) > 1 else 0.0,
                    '심각오류': int(np.sum(((yt == 0) & (p == 2)) | ((yt == 2) & (p == 0))))}

        grid_lh = [(L, H) for L in np.arange(0.10, 0.51, 0.05) for H in np.arange(0.50, 0.86, 0.05) if H > L]
        summ = []
        for crit in ['정확도', 'macro-F1', 'QWK']:
            bL, bH, bm, bv = None, None, None, -1
            for L, H in grid_lh:
                m = m_all(cls(L, H))
                if m[crit] > bv:
                    bv, bL, bH, bm = m[crit], L, H, m
            summ.append({'기준': crit, '최적 경계': f"[{bL:.2f}, {bH:.2f}]", '정확도': f"{bm['정확도']:.0%}",
                         'macro-F1': f"{bm['macro-F1']:.2f}", 'QWK': f"{bm['QWK']:.2f}", '심각오류': bm['심각오류']})
        st.dataframe(pd.DataFrame(summ), width="stretch", hide_index=True)

        gl = np.arange(0.10, 0.51, 0.05); gh = np.arange(0.50, 0.86, 0.05)
        qg = np.full((len(gl), len(gh)), np.nan)
        for a_, L in enumerate(gl):
            for b_, H in enumerate(gh):
                if H > L:
                    qg[a_, b_] = m_all(cls(L, H))['QWK']
        box = st.container(border=True); box.markdown("**경계별 QWK** · 밝을수록 좋음")
        fig = go.Figure(go.Heatmap(z=qg, x=[f"{h:.2f}" for h in gh], y=[f"{l:.2f}" for l in gl],
                                   colorscale='Viridis', colorbar=dict(title="QWK")))
        fig.update_layout(height=360, margin=dict(l=6, r=6, t=6, b=6),
                          xaxis_title="보통↔강 경계", yaxis_title="약↔보통 경계")
        box.plotly_chart(fig, width="stretch")
        st.caption("원하는 경계를 사이드바 슬라이더에 넣으면 전체 진단이 그 경계로 갱신됩니다.")
